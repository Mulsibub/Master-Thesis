
import numpy as np
import scipy.sparse as sparse


from flowtracing.source_to_sink import source_to_sink_class
from flowtracing.sink_to_source import sink_to_source_class
from flowtracing.sink_to_source import link_capacity
from scipy.integrate import cumulative_trapezoid
from scipy.integrate import trapezoid
from scipy.stats import norm

from scipy.stats import gaussian_kde
#%%




class flowtracing_class:
    """
    Initialization
    """
    def __init__(self,init,layout, n_bins=100):
        n_t = init.t
        for key, item in layout['Generation'].items():
            layout['Generation'][key] = item[0:n_t,:]
        for key in ['balancing', 'Flows', 'injection', 'mismatch']:
            layout['misc'][key] = layout['misc'][key][0:n_t,:]
        init.Load2 = init.Load[0:n_t,:]
        self.Injections = layout['misc']['injection'][0:n_t,:]
        self.link_data = init.link_data
        self.PTDF = self.link_data['PTDF'].astype(np.float32)
        self.incidence = sparse.csr_matrix(self.link_data['incidence']).astype(np.float32)
        self.adjacency = self.compute_adjacency_matrix(self.incidence).astype(np.float32)
        self.FlowPattern = self.Injections @ self.PTDF.T.astype(np.float32)
        self.t_total = n_t
        
        #Defining the clases
        self.init = init
        self.layout = layout
        
        #Init result matrixes
        self.total_export = np.zeros((self.init.n, self.init.n)).astype(np.float32)
        self.total_export_wind = np.zeros_like(self.total_export).astype(np.float32)
        self.total_export_solar = np.zeros_like(self.total_export).astype(np.float32)
        self.total_export_backup = np.zeros_like(self.total_export).astype(np.float32)
        self.total_use_trans = np.zeros((self.init.l,self.init.n)).astype(np.float32)
        
        (L,N) = np.shape(self.PTDF)
        self.L, self.N = L, N
        self.n_bins=n_bins
        self.bin_edges = np.linspace(0, 1, n_bins + 1)
        self.F2 = np.abs(self.FlowPattern)
        self.kappa_T = np.quantile(self.F2, q=0.99, axis=0).astype(np.float32)
        
        norm_flow = np.divide(self.F2, self.kappa_T)
        self.norm_flow = np.clip(norm_flow, 0, 1.0 - 1e-8)
        bin_indices = np.floor(np.multiply(self.norm_flow, n_bins-1))
        self.bin_indices = (bin_indices).astype(np.int32)
        self.sum_q = np.zeros((N, L, n_bins), dtype=np.float32)  # accumulate sums
        self.count_q = np.zeros((L, n_bins), dtype=np.int32)     # accumulate counts
        
    def compute_adjacency_matrix(self,incidence):
        """Compute the adjacency matrix using incidence matrix multiplication."""
        adjacency_matrix = incidence @ incidence.T
        adjacency_matrix.setdiag(0)
        return adjacency_matrix.todense()
    
    
    def run_source_to_sink(self, t):
        
        model = source_to_sink_class(self.adjacency,self.F_in,self.F_out,self.F_out_total,self.P_minus,self.P_plus)
        walk = model.walk()
        q_nn = model.q_nn(walk)
        q_wind, q_solar, q_backup = model.partition_q(t,q_nn,self.layout,self.init.Load2[t,:])
        return q_nn, q_wind, q_solar, q_backup
        
        

    
    def run_sink_to_source(self, t):
        model = sink_to_source_class(self.adjacency,self.F_in,self.F_out,self.F_in_total,self.P_minus,self.P_plus)
        walk = model.walk()
        q_nn = model.q_nn(walk)
        q_ln = model.q_ln(walk,q_nn)
        

        return q_ln#, q_nn, q_ln ,q_wind,q_solar,q_backup
    
    
    """
    Runing the script
    """
        
    def run(self):
        """"""""""""""""""""""""""""""""""""""""""""""""""""""""
        t_total = self.t_total
        # condprop = np.zeros((956,512))
        # Prepare accumulation arrays
        Q_ln = np.zeros((self.L, self.N, t_total), dtype=np.float32)
        # bins = np.linspace(0,1,100)
        # norm_flow = self.norm_flow
        
        bin_indices = self.bin_indices
        for t in range(t_total):
            print(f"timestep {t} of {t_total}")
            self.Initialize_time_step(t) #Get F,P and their variations for t
            q_nn, q_wind, q_solar, q_backup = self.run_source_to_sink(t)

            self.total_export += q_nn * self.P
            self.total_export_wind += q_wind * self.P
            self.total_export_solar += q_solar * self.P
            self.total_export_backup += q_backup * self.P
            
            
            
            
            q_ln = self.run_sink_to_source(t)
            
            Q_ln[:,:,t] = q_ln
            print(f'timestep {t} q_ln sum is= {q_ln.sum()}')
            
            Bin_ind =  bin_indices[t,:]
            self.CondAvg_acumulate(q_ln, Bin_ind)
            
            # self.CondAvg_acumulate(q_ln, t)
        # Q_ln.mean
        
            
        cond_avg = self.CondAvg_condition()
        self.compute_K_ln_T(cond_avg)
        # link_capacity_class = link_capacity(cond_avg, self.F2, self.P)
        # Pf_l = gaussian_kde(self.F2, bw_method='silverman')
        # # Define range of f_l values
        
        total_export = {
            'total':self.total_export,
            'wind':self.total_export_wind,
            'solar':self.total_export_solar,
            'backup':self.total_export_backup
        }
        
            
            
        result = {
            'total_export':total_export
            }
        
        return result

    
    def Initialize_time_step(self, t):
        """Initializes time step variables and stores them as instance attributes."""
        
        # Compute flow matrix and its positive/negative components
        F = self.incidence.multiply(sparse.csr_matrix(self.FlowPattern[t, :].T)).T
        F_out, F_in = F.multiply(F > 0), -F.multiply(F < 0)
    
        # Compute injection values and their positive/negative components
        P = self.Injections[t, :]
        P_plus, P_minus = P * (P > 0), -P * (P < 0)
    
        # Compute total flow in and out
        F_out_total, F_in_total = np.asarray(F_out.sum(axis=0)).ravel(), np.asarray(F_in.sum(axis=0)).ravel()
    
        # Store all computed values as instance attributes
        for var_name in ["F", "F_out", "F_in", "P", "P_plus", "P_minus", "F_out_total", "F_in_total"]:
            setattr(self, var_name, locals()[var_name])
            
    
    def CondAvg_acumulate(self, q_ln, Bin_ind):
        sum_q =  self.sum_q
        count_q = self.count_q
        L = self.L
        for l in range(L):
            b = Bin_ind[l]
            sum_q[:, l, b] += q_ln[l, :]
            count_q[l, b] += 1
        self.sum_q = sum_q
        self.count_q = count_q
        
        
    def CondAvg_condition(self):  
        with np.errstate(divide='ignore', invalid='ignore'):
            cond_avg = self.sum_q / self.count_q[None, :, :]
        # Replace NaNs from division by zero with 0
        cond_avg = np.nan_to_num(cond_avg, nan=(0))
        # cond_avg = np.nan_to_num(cond_avg, nan=0.0)
        # Convert to float32
        return cond_avg.astype(np.float32)        
    
    
    def compute_K_ln_T(self, cond_avg):
        """
        Compute K_ln^T based on the given equation using the conditional average.
        
        Parameters:
            cond_avg: np.ndarray, shape (956, 512, 100), conditional average <c_ln | f_l>
            
        Returns:
            K_ln_T: np.ndarray, shape (956, 512), effective capacity per node-link
        """
        def PDF(data, x, sample=False):
            if sample:
                n = len(data)-1
            else:
                n = len(data)
            mean = data.mean()
            sigma = 0
            for el in data:
                sigma += (el - mean)**2
            sigma = np.sqrt(sigma / n)
            return (1.0 / (sigma * np.sqrt(2*np.pi))) * np.exp(-0.5*((x - mean) / sigma) ** 2)
        
        
        # temp=np.sum(cond_avg,axis=0)
        f_l_t = self.F2
        kappa_l_T = self.kappa_T
        n_bins = self.n_bins
        N, L = self.N, self.L
        delta_f =  kappa_l_T/ n_bins  # bin width in normalized space
        

        # Build histograms for P_l(f_l) over normalized space
        
        P_l = np.zeros((L, n_bins))
        P_l2 = np.zeros((L, n_bins))
        P_l_cum = np.zeros((L, n_bins))
        P_l2_cum = np.zeros((L, n_bins))
        bin_edges = np.zeros((n_bins+1,L))
        for l in range(L):
            kappa_vals_l = np.arange(n_bins) * delta_f[l]
            P_l2[l,:] = PDF(f_l_t[:, l], kappa_vals_l)
            P_l2_cum[l,:] = cumulative_trapezoid(P_l2[l,:], dx=delta_f[l], initial=0)
            hist, bin_edges[:,l] = np.histogram(f_l_t[:, l], bins=n_bins, range=(0,kappa_l_T[l]), density=False)
            P_l[l,:] = hist / np.sum(hist)
        # P_l = np.nan_to_num(P_l, nan=0.0)    
        # # Cumulative distribution: P_l^C(kappa)
        P_l_cum = cumulative_trapezoid(P_l, initial=0)  # shape (956, 100)
       
        
        w_ln = np.zeros((n_bins, N, L), dtype=np.float32)
        #### Method 1 ###
        P3 = P_l2/ (1-P_l2_cum)
        P3=np.nan_to_num(P3, nan=0.0)
        inner = P3*cond_avg
        for k_idx in range(n_bins):
            for l in range(L):
                w_ln[k_idx,:,l]= trapezoid(inner[:, l, k_idx:]*delta_f[l], axis=1)
                
        ##### Method 2 ###        
        # inner = (P_l*cond_avg)
        # for k_idx in range(n_bins-1):
        #     # np.cumsum(P_l[:, :k_idx])
        #     denom = 1.0 - P_l_cum[:, k_idx]  # shape (L,)
        #     denom = np.where(denom == 0, 1e-8, denom)
        #     # denom = np.where(denom < 0, 1e-8, denom)
            
        #     # inner[:, :, k_idx:]
        #     for l in range(L):
        #         print(l)
        #         print(k_idx)
        #         temp = trapezoid(inner[:, l, k_idx:], dx=delta_f[l])
        #         # temp = (cumulative_trapezoid(inner[:, l, k_idx:], dx=delta_f[l]))[:,0]
        #         w_ln[k_idx,:,l] = (1/denom[l])*temp
        #     # w_ln[k_idx,:,:] =  (P_l[:, k_idx:].T/denom) * cond_avg[:, :, k_idx:] * delta_f
        
        K_ln_T = np.zeros((N, L), dtype=np.float32)    
        for l in range(L):
            # kappa_vals_l = np.arange(n_bins) * delta_f[l]
            K_ln_T[:,l] = trapezoid(w_ln[:,:,l], dx=delta_f[l], axis=0)
        np.allclose(K_ln_T.sum(axis=0), kappa_l_T, rtol=1e-1)
        return K_ln_T.astype(np.float16)



    
# import matplotlib.pyplot as plt
# import matplotlib as mpl
# mpl.use('ipympl')

# # Flatten across lines/time to check distribution
# all_bins = self.bin_indices.flatten()
# plt.hist(all_bins, bins=self.n_bins, range=(0, self.n_bins), edgecolor='black')
# plt.title("Bin Usage Histogram")
# plt.xlabel("Bin Index")
# plt.ylabel("Frequency")
# plt.show()
  


